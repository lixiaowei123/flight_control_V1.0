#ifndef __DEV_HMC5883L_H__
#define __DEV_HMC5883L_H__
#endif