#ifndef  __DEV_LED__H__
#define  __DEV_LED__H__


#include "stm32f4xx.h"




class DEV_LED
{

  public:
		    virtual void init(void)=0;

};


#endif
